public class Q26 {
    public static void main(String[] args) {
        System.out.println("Thread Name : " + Thread.currentThread().getName() + "\nPriority : "
                + Thread.currentThread().getPriority());
    }
}
