public class MultipleOfNumber {
    public static void main(String[] args) {
        int num=10;
        for(int i=1;i<=num;i++){
            int multi=num*i;
            System.err.println(num+"*"+i+"="+multi);
        }
    }
}
//output
//10*1=10
//10*2=20
//10*3=30
//10*4=40
//10*5=50
//10*6=60
//10*7=70
//10*8=80
//10*9=90
//10*10=100
