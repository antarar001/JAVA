

package copyright;

public class copyright {
    public static void main(String[] args) {
        System.out.println("Copyright © 2024 Subha Saha. All rights reserved.\n \n");
        
    }

}