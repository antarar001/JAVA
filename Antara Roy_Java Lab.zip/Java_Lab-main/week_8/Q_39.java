package week_8;

//39. Write a Java Program to Display the Character and the Corresponding Ascii Present in the String.
import java.util.Scanner;

public class Q_39 {
    public static void main(String[] args) {
        // Same as Q_38
    }
}
